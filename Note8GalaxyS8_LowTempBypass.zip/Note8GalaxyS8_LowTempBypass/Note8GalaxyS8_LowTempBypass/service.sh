#!/system/bin/sh
# Note 8 Low Temp Charging Bypass

sleep 25

echo -200 > /sys/class/power_supply/battery/batt_tune_temp_low_normal 2>/dev/null
echo -200 > /sys/class/power_supply/battery/batt_tune_temp_low_rec_normal 2>/dev/null
echo '500 480 -300 -250 500 480 -300 -250' > /sys/class/power_supply/battery/batt_temp_table 2>/dev/null

# re-apply a few times
(
sleep 30
echo -200 > /sys/class/power_supply/battery/batt_tune_temp_low_normal 2>/dev/null
echo -200 > /sys/class/power_supply/battery/batt_tune_temp_low_rec_normal 2>/dev/null
sleep 60
echo -200 > /sys/class/power_supply/battery/batt_tune_temp_low_normal 2>/dev/null
echo -200 > /sys/class/power_supply/battery/batt_tune_temp_low_rec_normal 2>/dev/null
) &
